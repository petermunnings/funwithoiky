﻿
namespace oikonomos.common.Models
{
    public class SuburbViewModel
    {
        public int SuburbId { get; set; }
        public string SuburbName { get; set; }
    }
}
