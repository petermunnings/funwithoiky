﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oikonomos.common.Models
{
    public class PersonListViewModel
    {
        public int PersonId { get; set; }
        public int FamilyId { get; set; }
        public string Surname { get; set; }
        public string Firstname { get; set; }
        public string HomePhone { get; set; }
        public string CellPhone { get; set; }
        public string WorkPhone { get; set; }
        public string Email { get; set; }
    }
}
