﻿namespace oikonomos.common.Models
{
    public class GroupClassificationViewModel
    {
        public int GroupClassificationId { get; set; }
        public string GroupClassification { get; set; }
    }
}
