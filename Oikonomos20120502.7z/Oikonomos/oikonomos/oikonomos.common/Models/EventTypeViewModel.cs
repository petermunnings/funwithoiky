﻿namespace oikonomos.common.Models
{
    public class EventTypeViewModel
    {
        public int EventTypeId { get; set; }
        public string EventType { get; set; }
    }
}
