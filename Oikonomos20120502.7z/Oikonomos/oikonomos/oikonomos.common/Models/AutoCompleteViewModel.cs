﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace oikonomos.common.Models
{
    public class AutoCompleteViewModel
    {
        public int id { get; set; }
        public string label { get; set; }
        public string value { get; set; }
    }
}
