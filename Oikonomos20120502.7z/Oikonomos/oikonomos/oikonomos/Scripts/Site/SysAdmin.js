﻿var newChurch;

function ChurchViewModel() {
    var self = this;

    self.church = ko.observable();
    $.get("/Ajax/InitializeChurchSettingsViewModel", self.church);

    self.createNewChurch = function () {
        var postData = ko.toJS(self.church);
        var jqxhr = $.post("/Ajax/CreateNewChurch", $.postify(postData), function (data) {
            alert(data.Message);
        }).error(function (jqXHR, textStatus, errorThrown) {
            SendErrorEmail("Error calling CreateNewChurch", jqXHR.responseText);
        });
    };
}


$(document).ready(function () {
    $("#ChurchId").change(function () {
        var postData = { churchId: $(this).val() };
        $.post("/Ajax/ChangeChurchTo", $.postify(postData));
    });

    $("#addNewChurch").click(function () {
        $("#add_Person").dialog(
        {
            modal: true,
            height: 600,
            width: 600,
            resizable: true,
            buttons: {
                "Create Church": function () {
                    newChurch.createNewChurch();

                    $(this).dialog("close");
                },
                Cancel: function () {
                    $(this).dialog("close");
                }
            }
        });
    });

    newChurch = new ChurchViewModel();
    ko.applyBindings(newChurch);
});