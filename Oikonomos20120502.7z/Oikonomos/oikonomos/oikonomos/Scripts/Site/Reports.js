﻿
$(document).ready(function () {

    $("#button_churchList").click(function () {
        window.location = "/Home/ReportGrid";
    });
    $("#button_churchMap").click(function () {
        window.location = "/Home/ReportsMap";
    });
    $("#button_adminReports").click(function () {
        window.location = "/Home/ReportsAdmin";
    });

})